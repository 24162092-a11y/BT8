package vn.iotstar.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/categories")
public class CategoryWebController {

    @GetMapping
    public String index() {
        return "category-list"; // Trỏ đến file category-list.html
    }
}