package vn.iotstar;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Bt8Application {

	public static void main(String[] args) {
		SpringApplication.run(Bt8Application.class, args);
	}

}
