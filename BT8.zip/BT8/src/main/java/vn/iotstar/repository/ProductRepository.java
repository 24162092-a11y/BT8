package vn.iotstar.repository;

import java.sql.Timestamp;
import java.util.Optional;
import java.util.stream.Stream;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import vn.iotstar.entity.Product;

@Repository
public interface ProductRepository extends JpaRepository<Product, Long> {

    // Tìm kiếm theo tên trả về Optional (dùng phổ biến trong Service)
    Optional<Product> findByProductName(String productName);

    // Tìm kiếm theo ngày tạo
    Optional<Product> findByCreateDate(Timestamp createDate);

    // Nếu muốn dùng Stream, bạn phải đổi tên phương thức để tránh trùng lặp
    Stream<Product> streamByProductName(String productName);
}