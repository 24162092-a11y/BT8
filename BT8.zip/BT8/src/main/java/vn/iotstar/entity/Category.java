package vn.iotstar.entity;

import jakarta.persistence.*;

@Entity
@Table(name = "categories")
public class Category {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, length = 100)
    private String categoryName;

    private String icon;

    private Boolean status;

    // 1. Constructor không tham số (No-args Constructor)
    public Category() {
    }

    // 2. Constructor đầy đủ tham số (All-args Constructor)
    public Category(Long id, String categoryName, String icon, Boolean status) {
        this.id = id;
        this.categoryName = categoryName;
        this.icon = icon;
        this.status = status;
    }

    // 3. Getters và Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getCategoryName() {
        return categoryName;
    }

    public void setCategoryName(String categoryName) {
        this.categoryName = categoryName;
    }

    public String getIcon() {
        return icon;
    }

    public void setIcon(String icon) {
        this.icon = icon;
    }

    public Boolean getStatus() {
        return status;
    }

    public void setStatus(Boolean status) {
        this.status = status;
    }
}