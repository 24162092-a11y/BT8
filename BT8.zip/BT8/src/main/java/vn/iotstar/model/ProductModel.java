package vn.iotstar.model;

import org.springframework.web.multipart.MultipartFile;
import lombok.*;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ProductModel {
    private Long productId;
    private String productName;
    private Integer quantity;
    private Double unitPrice;
    private String images;
    private MultipartFile imageFile;
    private String description;
    private Double discount;
    private Long categoryId;
}