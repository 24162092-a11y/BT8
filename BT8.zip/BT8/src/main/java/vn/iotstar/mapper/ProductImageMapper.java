package vn.iotstar.mapper;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import vn.iotstar.dto.ProductImageDTO;

@Component
public class ProductImageMapper {

    @Autowired
    private ModelMapper modelMapper;

    public ProductImageDTO toDto(Object entity) {
        if (entity == null) return null;
        return modelMapper.map(entity, ProductImageDTO.class);
    }
}