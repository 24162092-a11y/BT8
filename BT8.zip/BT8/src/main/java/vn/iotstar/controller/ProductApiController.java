package vn.iotstar.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import vn.iotstar.entity.Category;
import vn.iotstar.entity.Product;
import vn.iotstar.service.IProductService;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping({"/api/products", "/api/product"})
@CrossOrigin(origins = "*")
public class ProductApiController {

    @Autowired
    private IProductService productService;

    // 1. GET ALL SẢN PHẨM
    @GetMapping
    public ResponseEntity<List<Product>> getAllProducts() {
        return ResponseEntity.ok(productService.findAll());
    }

    // 2. GET CHI TIẾT SẢN PHẨM (Tự ép kiểu id sang int/Integer)
    @GetMapping("/{id}")
    public ResponseEntity<?> getProductById(@PathVariable("id") Long id) {
        Optional<Product> product = productService.findById(id.intValue());
        if (product.isPresent()) {
            return ResponseEntity.ok(product.get());
        }
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Không tìm thấy sản phẩm ID = " + id);
    }

    // 3. POST: THÊM SẢN PHẨM MỚI
    @PostMapping
    public ResponseEntity<?> createProduct(
            @RequestParam("productName") String productName,
            @RequestParam("unitPrice") Double unitPrice,
            @RequestParam(value = "discount", defaultValue = "0") Double discount,
            @RequestParam("quantity") Integer quantity,
            @RequestParam(value = "description", required = false) String description,
            @RequestParam("categoryId") Long categoryId,
            @RequestParam(value = "imageFile", required = false) MultipartFile imageFile) {

        try {
            Product product = new Product();
            product.setProductName(productName);
            product.setUnitPrice(unitPrice);
            product.setDiscount(discount);
            product.setQuantity(quantity);
            product.setDescription(description);

            // Gán Category khớp field id kiểu Long
            Category category = new Category();
            category.setId(categoryId);
            product.setCategory(category);

            // Xử lý lưu tên file ảnh
            if (imageFile != null && !imageFile.isEmpty()) {
                product.setImages(imageFile.getOriginalFilename());
            } else {
                product.setImages("default.png");
            }

            Product savedProduct = productService.save(product);
            return ResponseEntity.status(HttpStatus.CREATED).body(savedProduct);

        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body("Lỗi khi thêm sản phẩm: " + e.getMessage());
        }
    }

    // 4. PUT: CẬP NHẬT SẢN PHẨM
    @PutMapping("/{id}")
    public ResponseEntity<?> updateProduct(
            @PathVariable("id") Long id,
            @RequestParam("productName") String productName,
            @RequestParam("unitPrice") Double unitPrice,
            @RequestParam(value = "discount", defaultValue = "0") Double discount,
            @RequestParam("quantity") Integer quantity,
            @RequestParam(value = "description", required = false) String description,
            @RequestParam("categoryId") Long categoryId,
            @RequestParam(value = "imageFile", required = false) MultipartFile imageFile) {

        Optional<Product> optionalProduct = productService.findById(id.intValue());
        if (optionalProduct.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Không tìm thấy sản phẩm để cập nhật");
        }

        try {
            Product product = optionalProduct.get();
            product.setProductName(productName);
            product.setUnitPrice(unitPrice);
            product.setDiscount(discount);
            product.setQuantity(quantity);
            product.setDescription(description);

            Category category = new Category();
            category.setId(categoryId);
            product.setCategory(category);

            if (imageFile != null && !imageFile.isEmpty()) {
                product.setImages(imageFile.getOriginalFilename());
            }

            Product updatedProduct = productService.save(product);
            return ResponseEntity.ok(updatedProduct);

        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Lỗi khi cập nhật sản phẩm: " + e.getMessage());
        }
    }

    // 5. DELETE: XÓA SẢN PHẨM
    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteProduct(@PathVariable("id") Long id) {
        try {
            productService.deleteById(id.intValue());
            return ResponseEntity.ok().body("{\"message\": \"Xóa thành công\"}");
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("Lỗi khi xóa sản phẩm: " + e.getMessage());
        }
    }
}