package vn.iotstar.controller;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import vn.iotstar.entity.Category;
import vn.iotstar.model.Response;
import vn.iotstar.service.CategoryService;

import java.util.List;
import java.util.Optional;

@RestController
// Hỗ trợ cả đường dẫn có /v1 và không có /v1 để Ajax luôn gọi thành công
@RequestMapping({"/api/v1/categories", "/api/categories", "/api/category"})
@CrossOrigin(origins = "*") 
@Tag(name = "Category Controller", description = "Quản lý CRUD cho Danh Mục Product")
public class CategoryController {

    @Autowired
    private CategoryService categoryService;

    // 1. GET: Lấy danh sách tất cả các Category
    @GetMapping
    @Operation(summary = "Lấy danh sách tất cả danh mục")
    public ResponseEntity<Response> getAllCategories() {
        List<Category> list = categoryService.findAll();
        // SỬA LỖI: Truyền danh sách 'list' vào Response (Data)
        return ResponseEntity.ok(new Response(true, "Lấy danh sách thành công", list));
    }

    // 2. GET: Lấy thông tin Category theo ID
    @GetMapping("/{id}")
    @Operation(summary = "Lấy thông tin danh mục theo ID")
    public ResponseEntity<Response> getCategoryById(@PathVariable Long id) {
        Optional<Category> category = categoryService.findById(id);
        if (category.isPresent()) {
            return ResponseEntity.ok(new Response(true, "Tìm thấy danh mục", category.get()));
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(new Response(false, "Không tìm thấy danh mục với ID = " + id, null));
        }
    }

    // 3. POST: Tạo mới một Category
    @PostMapping
    @Operation(summary = "Thêm mới danh mục")
    public ResponseEntity<Response> createCategory(@RequestBody Category category) {
        Category savedCategory = categoryService.save(category);
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(new Response(true, "Tạo mới danh mục thành công", savedCategory));
    }

    // 4. PUT: Chỉnh sửa/Cập nhật Category theo ID
    @PutMapping("/{id}")
    @Operation(summary = "Cập nhật danh mục theo ID")
    public ResponseEntity<Response> updateCategory(@PathVariable Long id, @RequestBody Category categoryDetails) {
        Optional<Category> categoryData = categoryService.findById(id);
        if (categoryData.isPresent()) {
            Category category = categoryData.get();
            category.setCategoryName(categoryDetails.getCategoryName());
            category.setIcon(categoryDetails.getIcon());
            category.setStatus(categoryDetails.getStatus());

            Category updatedCategory = categoryService.save(category);
            return ResponseEntity.ok(new Response(true, "Cập nhật danh mục thành công", updatedCategory));
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(new Response(false, "Không tìm thấy danh mục để cập nhật", null));
        }
    }

    // 5. DELETE: Xóa Category theo ID
    @DeleteMapping("/{id}")
    @Operation(summary = "Xóa danh mục theo ID")
    public ResponseEntity<Response> deleteCategory(@PathVariable Long id) {
        Optional<Category> categoryData = categoryService.findById(id);
        if (categoryData.isPresent()) {
            categoryService.deleteById(id);
            return ResponseEntity.ok(new Response(true, "Xóa danh mục thành công", null));
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(new Response(false, "Không tìm thấy danh mục để xóa", null));
        }
    }
}