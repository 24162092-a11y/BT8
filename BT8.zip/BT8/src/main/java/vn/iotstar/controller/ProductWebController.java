package vn.iotstar.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/admin/products")
public class ProductWebController {

    @GetMapping
    public String index() {
        // Thêm đường dẫn thư mục "admin/" vào trước tên file
        return "admin/product-ajax"; 
    }
}