package vn.iotstar.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/admin/categories")
public class CategoryWebController {

    @GetMapping
    public String index() {
        // Trả về tên file "category-ajax" (ghép với prefix/suffix sẽ thành /WEB-INF/views/category-ajax.jsp)
    	return "admin/category-ajax";
    }
}