package vn.iotstar.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class HomeController {

    @GetMapping("/")
    public String index() {
        // Tự động chuyển hướng về trang quản lý sản phẩm
        return "redirect:/admin/products";
    }
}