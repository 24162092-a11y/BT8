package vn.iotstar.service;

import java.sql.Timestamp;
import java.util.List;
import java.util.Optional;

import org.springframework.web.multipart.MultipartFile;

import vn.iotstar.dto.ProductDTO;
import vn.iotstar.entity.Product;
import vn.iotstar.model.ProductModel;

public interface IProductService {

    List<ProductDTO> findAll();

    Optional<ProductDTO> findById(Long id);

    Optional<ProductDTO> findByProductName(String productName);

    Optional<ProductDTO> findByCreateDate(Timestamp createDate);

    ProductDTO save(ProductDTO dto);

    void deleteById(Long id);

    void save(ProductModel productModel, MultipartFile imageFile);
}