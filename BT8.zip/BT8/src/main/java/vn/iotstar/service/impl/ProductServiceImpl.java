package vn.iotstar.service.impl;

import java.sql.Timestamp;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import vn.iotstar.dto.ProductDTO;
import vn.iotstar.entity.Category;
import vn.iotstar.entity.Product;
import vn.iotstar.mapper.ProductMapper;
import vn.iotstar.model.ProductModel;
import vn.iotstar.repository.CategoryRepository;
import vn.iotstar.repository.ProductRepository;
import vn.iotstar.service.IProductService;

@Service
public class ProductServiceImpl implements IProductService {

    @Autowired
    private ProductRepository productRepository;

    @Autowired
    private CategoryRepository categoryRepository;

    @Autowired
    private ProductMapper productMapper;

    @Override
    public List<ProductDTO> findAll() {
        return productRepository.findAll()
                .stream()
                .map(productMapper::toDto)
                .collect(Collectors.toList());
    }

    @Override
    public Optional<ProductDTO> findById(Long id) {
        return productRepository.findById(id)
                .map(productMapper::toDto);
    }

    @Override
    public Optional<ProductDTO> findByProductName(String productName) {
        return productRepository.findByProductName(productName)
                .map(productMapper::toDto);
    }

    @Override
    public Optional<ProductDTO> findByCreateDate(Timestamp createDate) {
        return productRepository.findByCreateDate(createDate)
                .map(productMapper::toDto);
    }

    @Override
    public ProductDTO save(ProductDTO dto) {
        Product entity = productMapper.toEntity(dto);

        if (entity.getCreateDate() == null) {
            entity.setCreateDate(new Timestamp(System.currentTimeMillis()));
        }

        if (dto.getCategoryId() != null) {
            Category category = categoryRepository.findById(dto.getCategoryId())
                    .orElse(null);
            entity.setCategory(category);
        }

        Product savedEntity = productRepository.save(entity);
        return productMapper.toDto(savedEntity);
    }

    @Override
    public void deleteById(Long id) {
        productRepository.deleteById(id);
    }

    @Override
    public void save(ProductModel productModel, MultipartFile imageFile) {
        // Xử lý upload file nếu sử dụng ProductModel
    }
}