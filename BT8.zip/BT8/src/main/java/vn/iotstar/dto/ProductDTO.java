package vn.iotstar.dto;

import java.sql.Timestamp;

public class ProductDTO {
    private Long productId;
    private String productName;
    private String images;
    private Double unitPrice;
    private Double discount;
    private Integer quantity;
    private String description;
    private Timestamp createDate;
    
    private Long categoryId;
    private String categoryName;

    public ProductDTO() {
    }

    public ProductDTO(Long productId, String productName, String images, Double unitPrice, Double discount,
                      Integer quantity, String description, Timestamp createDate, Long categoryId, String categoryName) {
        this.productId = productId;
        this.productName = productName;
        this.images = images;
        this.unitPrice = unitPrice;
        this.discount = discount;
        this.quantity = quantity;
        this.description = description;
        this.createDate = createDate;
        this.categoryId = categoryId;
        this.categoryName = categoryName;
    }

    public Long getProductId() {
        return productId;
    }

    public void setProductId(Long productId) {
        this.productId = productId;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getImages() {
        return images;
    }

    public void setImages(String images) {
        this.images = images;
    }

    public Double getUnitPrice() {
        return unitPrice;
    }

    public void setUnitPrice(Double unitPrice) {
        this.unitPrice = unitPrice;
    }

    public Double getDiscount() {
        return discount;
    }

    public void setDiscount(Double discount) {
        this.discount = discount;
    }

    public Integer getQuantity() {
        return quantity;
    }

    public void setQuantity(Integer quantity) {
        this.quantity = quantity;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Timestamp getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Timestamp createDate) {
        this.createDate = createDate;
    }

    public Long getCategoryId() {
        return categoryId;
    }

    public void setCategoryId(Long categoryId) {
        this.categoryId = categoryId;
    }

    public String getCategoryName() {
        return categoryName;
    }

    public void setCategoryName(String categoryName) {
        this.categoryName = categoryName;
    }
}